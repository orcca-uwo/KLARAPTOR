#ifndef EVAL_shared_mem_bytes_dynamic_gtx760m_H_
#define EVAL_shared_mem_bytes_dynamic_gtx760m_H_

//////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>
#include "/data/repos/svn/program_analysis/ProgramAnalysis/ParametricKernels/PTX/klaraptor/src/RatFunInterp/include/interpolator.h"

//////////////////////////////////////////
AltArr_t* get_numer_shared_mem_bytes_dynamic()
{
AltArr_t* x = makePolynomial_AA(18, 3);
mpq_init(x->elems[0].coef);
mpz_set_str(mpq_numref(x->elems[0].coef), "-54657835033339", 10);
mpz_set_str(mpq_denref(x->elems[0].coef), "10889035741470028412976348208558233354240", 10);
x->elems[0].degs = 281475513581570;
mpq_init(x->elems[1].coef);
mpz_set_str(mpq_numref(x->elems[1].coef), "28376675127861", 10);
mpz_set_str(mpq_denref(x->elems[1].coef), "14178431955039099496062953396560199680", 10);
x->elems[1].degs = 281475513581569;
mpq_init(x->elems[2].coef);
mpz_set_str(mpq_numref(x->elems[2].coef), "-10900980649017", 10);
mpz_set_str(mpq_denref(x->elems[2].coef), "55384499824371482406495911705313280", 10);
x->elems[2].degs = 281475513581568;
mpq_init(x->elems[3].coef);
mpz_set_str(mpq_numref(x->elems[3].coef), "32093598408617", 10);
mpz_set_str(mpq_denref(x->elems[3].coef), "8307674973655722360974386755796992", 10);
x->elems[3].degs = 281475245146114;
mpq_init(x->elems[4].coef);
mpz_set_str(mpq_numref(x->elems[4].coef), "552339011611", 10);
mpz_set_str(mpq_denref(x->elems[4].coef), "4153837486827861180487193377898496", 10);
x->elems[4].degs = 281475245146113;
mpq_init(x->elems[5].coef);
mpz_set_str(mpq_numref(x->elems[5].coef), "8619402007181", 10);
mpz_set_str(mpq_denref(x->elems[5].coef), "41538374868278611804871933778984960", 10);
x->elems[5].degs = 281475245146112;
mpq_init(x->elems[6].coef);
mpz_set_str(mpq_numref(x->elems[6].coef), "10063429242629", 10);
mpz_set_str(mpq_denref(x->elems[6].coef), "5444517870735014206488174104279116677120", 10);
x->elems[6].degs = 281474976710658;
mpq_init(x->elems[7].coef);
mpz_set_str(mpq_numref(x->elems[7].coef), "42428613775967", 10);
mpz_set_str(mpq_denref(x->elems[7].coef), "7089215977519549748031476698280099840", 10);
x->elems[7].degs = 281474976710657;
mpq_init(x->elems[8].coef);
mpz_set_str(mpq_numref(x->elems[8].coef), "-107686242961261", 10);
mpz_set_str(mpq_denref(x->elems[8].coef), "41538374868278611804871933778984960", 10);
x->elems[8].degs = 281474976710656;
mpq_init(x->elems[9].coef);
mpz_set_str(mpq_numref(x->elems[9].coef), "13967399060621", 10);
mpz_set_str(mpq_denref(x->elems[9].coef), "54086425609737775787593663774720", 10);
x->elems[9].degs = 536870914;
mpq_init(x->elems[10].coef);
mpz_set_str(mpq_numref(x->elems[10].coef), "-50281506006577", 10);
mpz_set_str(mpq_denref(x->elems[10].coef), "10141204801825832960173811957760", 10);
x->elems[10].degs = 536870913;
mpq_init(x->elems[11].coef);
mpz_set_str(mpq_numref(x->elems[11].coef), "-8089632468007", 10);
mpz_set_str(mpq_denref(x->elems[11].coef), "27043212804868887893796831887360", 10);
x->elems[11].degs = 536870912;
mpq_init(x->elems[12].coef);
mpz_set_str(mpq_numref(x->elems[12].coef), "-5347970497", 10);
mpz_set_str(mpq_denref(x->elems[12].coef), "205453504556038271942949966199211950080", 10);
x->elems[12].degs = 268435458;
mpq_init(x->elems[13].coef);
mpz_set_str(mpq_numref(x->elems[13].coef), "-6509313223319", 10);
mpz_set_str(mpq_denref(x->elems[13].coef), "3544607988759774874015738349140049920", 10);
x->elems[13].degs = 268435457;
mpq_init(x->elems[14].coef);
mpz_set_str(mpq_numref(x->elems[14].coef), "-100317210448043", 10);
mpz_set_str(mpq_denref(x->elems[14].coef), "110768999648742964812991823410626560", 10);
x->elems[14].degs = 268435456;
mpq_init(x->elems[15].coef);
mpz_set_str(mpq_numref(x->elems[15].coef), "61340064513153", 10);
mpz_set_str(mpq_denref(x->elems[15].coef), "108172851219475551575187327549440", 10);
x->elems[15].degs = 2;
mpq_init(x->elems[16].coef);
mpz_set_str(mpq_numref(x->elems[16].coef), "-622282207205", 10);
mpz_set_str(mpq_denref(x->elems[16].coef), "10563755001901909333514387456", 10);
x->elems[16].degs = 1;
mpq_init(x->elems[17].coef);
mpz_set_str(mpq_numref(x->elems[17].coef), "28627073175017", 10);
mpz_set_str(mpq_denref(x->elems[17].coef), "26409387504754773333785968640", 10);
x->elems[17].degs = 0;
x->size = 18;

return x;
}

//////////////////////////////////////////
AltArr_t* get_denom_shared_mem_bytes_dynamic()
{
AltArr_t* x = makePolynomial_AA(1, 3);
mpq_init(x->elems[0].coef);
mpz_set_str(mpq_numref(x->elems[0].coef), "1", 10);
mpz_set_str(mpq_denref(x->elems[0].coef), "1", 10);
x->elems[0].degs = 281475513581570;
x->size = 1;

return x;
}

//////////////////////////////////////////
#endif
//////////////////////////////////////////
