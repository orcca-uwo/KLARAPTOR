#ifndef EVAL_registers_gtx760m_H_
#define EVAL_registers_gtx760m_H_

//////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>
#include "/data/repos/svn/program_analysis/ProgramAnalysis/ParametricKernels/PTX/klaraptor/src/RatFunInterp/include/interpolator.h"

//////////////////////////////////////////
AltArr_t* get_numer_registers()
{
AltArr_t* x = makePolynomial_AA(1, 0);
mpq_init(x->elems[0].coef);
mpz_set_str(mpq_numref(x->elems[0].coef), "18", 10);
mpz_set_str(mpq_denref(x->elems[0].coef), "1", 10);
x->elems[0].degs = 0;
x->size = 1;

return x;
}

//////////////////////////////////////////
AltArr_t* get_denom_registers()
{
AltArr_t* x = makePolynomial_AA(1, 0);
mpq_init(x->elems[0].coef);
mpz_set_str(mpq_numref(x->elems[0].coef), "1", 10);
mpz_set_str(mpq_denref(x->elems[0].coef), "1", 10);
x->elems[0].degs = 0;
x->size = 1;

return x;
}

//////////////////////////////////////////
#endif
//////////////////////////////////////////
