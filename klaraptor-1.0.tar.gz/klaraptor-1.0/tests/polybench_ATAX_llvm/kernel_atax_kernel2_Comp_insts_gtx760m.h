#ifndef EVAL_Comp_insts_gtx760m_H_
#define EVAL_Comp_insts_gtx760m_H_

//////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>
#include "/data/repos/svn/program_analysis/ProgramAnalysis/ParametricKernels/PTX/klaraptor/src/RatFunInterp/include/interpolator.h"

//////////////////////////////////////////
AltArr_t* get_numer_Comp_insts()
{
AltArr_t* x = makePolynomial_AA(2, 3);
mpq_init(x->elems[0].coef);
mpz_set_str(mpq_numref(x->elems[0].coef), "-155196787340819", 10);
mpz_set_str(mpq_denref(x->elems[0].coef), "5450803643664080", 10);
x->elems[0].degs = 1;
mpq_init(x->elems[1].coef);
mpz_set_str(mpq_numref(x->elems[1].coef), "262800629571559968", 10);
mpz_set_str(mpq_denref(x->elems[1].coef), "340675227729005", 10);
x->elems[1].degs = 0;
x->size = 2;

return x;
}

//////////////////////////////////////////
AltArr_t* get_denom_Comp_insts()
{
AltArr_t* x = makePolynomial_AA(1, 3);
mpq_init(x->elems[0].coef);
mpz_set_str(mpq_numref(x->elems[0].coef), "1", 10);
mpz_set_str(mpq_denref(x->elems[0].coef), "1", 10);
x->elems[0].degs = 0;
x->size = 1;

return x;
}

//////////////////////////////////////////
#endif
//////////////////////////////////////////
