/*!
 \file kernel_info_header_template.h
 \author Davood Mohajerani <dmohajer@uwo.ca>
 \brief
 */

#ifndef EVAL_KERNEL_INFO_atax_kernel1_H_
#define EVAL_KERNEL_INFO_atax_kernel1_H_
///////////////////////////////////////
//#include "mcwp/mcwp_data_types.h"

///////////////////////////////////////

typedef struct kernel_info_s {
	int nvar;
	point_set_t * eval_point_set;
	int device_compute_capability;
	char kernel_name[256];
	char device_name[256];
} kernel_info_t;

///////////////////////////////////////

int kernel_info_init(kernel_info_t* k) {
	k->nvar = 3;
	k->eval_point_set = (&global_bx_by);
	k->device_compute_capability = 30;

	sprintf(k->kernel_name, "atax_kernel1");
	sprintf(k->device_name, "gtx760m");
	return EXIT_SUCCESS;
}

///////////////////////////////////////
#endif
