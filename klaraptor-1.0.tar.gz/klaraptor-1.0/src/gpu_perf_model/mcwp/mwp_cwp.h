
#ifndef MWP_CWP_H_
#define MWP_CWP_H_

//#include "../../mcwp/mcwp.h"
//// add KLARAPTOR_PATH to include path
#include "mcwp/mcwp.h"

#endif 

